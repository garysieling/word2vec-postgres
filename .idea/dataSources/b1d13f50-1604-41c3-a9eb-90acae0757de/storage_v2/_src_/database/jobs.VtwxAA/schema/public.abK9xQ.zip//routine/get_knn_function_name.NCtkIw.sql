create function get_knn_function_name()
  returns character varying
immutable
language sql
as $$
SELECT varchar 'k_nearest_neighbour'
$$;

alter function get_knn_function_name()
  owner to postgres;

