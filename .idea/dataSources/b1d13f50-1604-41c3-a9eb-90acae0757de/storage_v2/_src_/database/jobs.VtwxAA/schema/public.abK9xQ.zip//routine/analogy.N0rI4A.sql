create function analogy(a character varying, b character varying, c character varying, OUT result character varying)
  returns character varying
language plpgsql
as $$
DECLARE
function_name varchar;
BEGIN
EXECUTE 'SELECT get_analogy_function_name()' INTO function_name;
EXECUTE format('
SELECT * FROM %s(''%s'', ''%s'',''%s'')
', function_name, replace(a, '''', ''''''), replace(b, '''', ''''''), replace(c, '''', '''''')) INTO result;
END
$$;

alter function analogy(varchar, varchar, varchar, out varchar)
  owner to postgres;

