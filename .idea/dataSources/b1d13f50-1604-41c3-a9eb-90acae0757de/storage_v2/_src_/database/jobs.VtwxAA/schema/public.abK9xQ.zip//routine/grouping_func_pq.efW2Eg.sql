create function grouping_func_pq(tokens character varying[], groups character varying[])
  returns TABLE(token character varying, grouptoken character varying)
language plpgsql
as $$
DECLARE
table_name varchar;
groups_formated varchar[];
tokens_formated varchar[];
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
FOR I IN array_lower(groups, 1)..array_upper(groups, 1) LOOP
  groups_formated[I] = replace(groups[I], '''', '''''');
END LOOP;
FOR I IN array_lower(tokens, 1)..array_upper(tokens, 1) LOOP
  tokens_formated[I] = replace(tokens[I], '''', '''''');
END LOOP;

RETURN QUERY EXECUTE format('
SELECT v1.word, v2.word
FROM grouping_pq(ARRAY(SELECT id FROM %s WHERE word = ANY (''%s'')),ARRAY(SELECT id FROM %s WHERE word = ANY (''%s''))) AS (token_id integer, group_id integer)
INNER JOIN %s AS v1 ON v1.id = token_id
INNER JOIN %s AS v2 ON v2.id = group_id
', table_name, tokens_formated, table_name, groups_formated, table_name, table_name);
END
$$;

alter function grouping_func_pq(character varying [], character varying [])
  owner to postgres;

