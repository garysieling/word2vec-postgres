create function k_nearest_neighbour_pq(token character varying, k integer)
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
table_name varchar;
pq_quantization_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE 'SELECT get_vecs_name_pq_quantization()' INTO pq_quantization_name;
RETURN QUERY EXECUTE format('
SELECT pqs.word AS word, (1.0 - (distance / 2.0))::float4 AS similarity
FROM %s AS gv, pq_search(gv.vector, %s) AS (idx integer, distance float4)
INNER JOIN %s AS pqs ON idx = pqs.id
WHERE gv.word = ''%s''
', table_name, k, pq_quantization_name, replace(token, '''', ''''''));
END
$$;

alter function k_nearest_neighbour_pq(varchar, integer)
  owner to postgres;

