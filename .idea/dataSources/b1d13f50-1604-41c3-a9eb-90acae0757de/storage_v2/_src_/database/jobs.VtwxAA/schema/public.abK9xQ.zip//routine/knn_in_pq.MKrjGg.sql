create function knn_in_pq(query_vector bytea, k integer, input_set character varying[])
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
table_name varchar;
pq_quantization_name varchar;
formated varchar[];
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE 'SELECT get_vecs_name_pq_quantization()' INTO pq_quantization_name;
FOR I IN array_lower(input_set, 1)..array_upper(input_set, 1) LOOP
  formated[I] = replace(input_set[I], '''', '''''');
END LOOP;

RETURN QUERY EXECUTE format('
SELECT pqs.word, (1.0 - (distance / 2.0))::float4
FROM pq_search_in(''%s'', %s, ARRAY(SELECT id FROM %s WHERE word = ANY (''%s''::varchar(100)[]))) AS (result_id integer, distance float4)
INNER JOIN %s AS pqs ON result_id = pqs.id
', query_vector, k, table_name, formated, pq_quantization_name);
END
$$;

alter function knn_in_pq(bytea, integer, character varying [])
  owner to postgres;

