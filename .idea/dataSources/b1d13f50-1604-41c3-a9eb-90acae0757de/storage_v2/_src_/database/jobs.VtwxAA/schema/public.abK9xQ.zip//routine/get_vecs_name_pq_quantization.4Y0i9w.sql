create function get_vecs_name_pq_quantization()
  returns regclass
immutable
language sql
as $$
SELECT regclass 'pq_quantization'
$$;

alter function get_vecs_name_pq_quantization()
  owner to postgres;

