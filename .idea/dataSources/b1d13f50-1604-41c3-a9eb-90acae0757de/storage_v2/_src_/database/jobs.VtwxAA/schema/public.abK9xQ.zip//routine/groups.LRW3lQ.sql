create function groups(tokens character varying[], groups character varying[])
  returns TABLE(token character varying, grouptoken character varying)
language plpgsql
as $$
DECLARE
function_name varchar;
formated_tokens varchar[];
formated_groups varchar[];
BEGIN
FOR I IN array_lower(tokens, 1)..array_upper(tokens, 1) LOOP
  formated_tokens[I] = replace(tokens[I], '''', '''''');
END LOOP;
FOR I IN array_lower(groups, 1)..array_upper(groups, 1) LOOP
  formated_groups[I] = replace(groups[I], '''', '''''');
END LOOP;
EXECUTE 'SELECT get_groups_function_name()' INTO function_name;
RETURN QUERY EXECUTE format('
SELECT * FROM %s(''%s''::varchar(100)[], ''%s''::varchar(100)[])
', function_name, formated_tokens, formated_groups);
END
$$;

alter function groups(character varying [], character varying [])
  owner to postgres;

