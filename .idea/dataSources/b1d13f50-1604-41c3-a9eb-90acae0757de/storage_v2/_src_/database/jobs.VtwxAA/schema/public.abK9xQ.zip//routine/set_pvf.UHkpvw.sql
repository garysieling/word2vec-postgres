create function set_pvf(f integer)
  returns void
language plpgsql
as $$
BEGIN
EXECUTE format('CREATE OR REPLACE FUNCTION get_pvf() RETURNS integer AS ''SELECT %s'' LANGUAGE sql IMMUTABLE', f);
END
$$;

alter function set_pvf(integer)
  owner to postgres;

