create function get_knn_in_function_name()
  returns character varying
immutable
language sql
as $$
SELECT varchar 'knn_in_exact'
$$;

alter function get_knn_in_function_name()
  owner to postgres;

