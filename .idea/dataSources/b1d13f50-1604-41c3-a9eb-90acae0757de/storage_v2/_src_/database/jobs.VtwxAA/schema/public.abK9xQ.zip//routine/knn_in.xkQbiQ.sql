create function knn_in(query character varying, k integer, input_set character varying[])
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
function_name varchar;
formated varchar[];
BEGIN
FOR I IN array_lower(input_set, 1)..array_upper(input_set, 1) LOOP
  formated[I] = replace(input_set[I], '''', '''''');
END LOOP;
EXECUTE 'SELECT get_knn_in_function_name()' INTO function_name;
RETURN QUERY EXECUTE format('
SELECT * FROM %s(''%s'', %s, ''%s''::varchar(100)[])
', function_name,  replace(query, '''', ''''''), k, formated);
END
$$;

alter function knn_in(varchar, integer, character varying [])
  owner to postgres;

