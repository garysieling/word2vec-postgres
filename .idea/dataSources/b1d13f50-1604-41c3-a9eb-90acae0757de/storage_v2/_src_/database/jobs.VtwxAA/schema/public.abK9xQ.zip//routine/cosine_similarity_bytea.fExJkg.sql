create function cosine_similarity_bytea(vector bytea, token2 character varying, OUT result real)
  returns real
language plpgsql
as $$
DECLARE
table_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;

EXECUTE format('
SELECT cosine_similarity_bytea(''%s'', t2.vector)
FROM %s AS t2
WHERE t2.word = ''%s''
', vector, table_name, replace(token2, '''', '''''')) INTO result;
END
$$;

alter function cosine_similarity_bytea(bytea, varchar, out real)
  owner to postgres;

