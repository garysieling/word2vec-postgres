create function get_groups_function_name()
  returns character varying
immutable
language sql
as $$
SELECT varchar 'grouping_func'
$$;

alter function get_groups_function_name()
  owner to postgres;

