create function get_w()
  returns integer
immutable
language sql
as $$
SELECT 3
$$;

alter function get_w()
  owner to postgres;

