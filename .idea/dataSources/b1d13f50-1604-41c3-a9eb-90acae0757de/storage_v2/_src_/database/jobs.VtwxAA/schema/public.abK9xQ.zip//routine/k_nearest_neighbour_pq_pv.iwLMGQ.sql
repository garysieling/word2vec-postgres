create function k_nearest_neighbour_pq_pv(input_vector anyarray, k integer)
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
pq_quantization_name varchar;
post_verif integer;
BEGIN
EXECUTE 'SELECT get_vecs_name_pq_quantization()' INTO pq_quantization_name;
EXECUTE 'SELECT get_pvf()' INTO post_verif;
RETURN QUERY EXECUTE format('
SELECT pqs.word AS word, cosine_similarity_bytea(''%s''::float4[], pqs.word) AS similarity
FROM pq_search(''%s''::float4[], %s) AS (idx integer, distance float4)
INNER JOIN %s AS pqs ON idx = pqs.id
ORDER BY cosine_similarity_bytea(''%s''::float4[], pqs.word) DESC
FETCH FIRST %s ROWS ONLY
', input_vector, post_verif*k, pq_quantization_name, input_vector, k);
END
$$;

alter function k_nearest_neighbour_pq_pv(anyarray, integer)
  owner to postgres;

