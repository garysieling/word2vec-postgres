create function get_vecs_name_coarse_quantization()
  returns regclass
immutable
language sql
as $$
SELECT regclass 'coarse_quantization'
$$;

alter function get_vecs_name_coarse_quantization()
  owner to postgres;

