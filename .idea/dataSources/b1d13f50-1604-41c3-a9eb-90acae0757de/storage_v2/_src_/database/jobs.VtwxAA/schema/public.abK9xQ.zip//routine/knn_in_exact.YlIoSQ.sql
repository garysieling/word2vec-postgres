create function knn_in_exact(query_vector bytea, k integer, input_set character varying[])
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
table_name varchar;
formated varchar[];
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
-- execute replace on every element of input set
FOR I IN array_lower(input_set, 1)..array_upper(input_set, 1) LOOP
  formated[I] = replace(input_set[I], '''', '''''');
END LOOP;
RETURN QUERY EXECUTE format('
SELECT v2.word, cosine_similarity_bytea(''%s'', v2.vector) FROM %s AS v2
WHERE v2.word = ANY (''%s''::varchar(100)[])
ORDER BY cosine_similarity_bytea(''%s'', v2.vector) DESC
FETCH FIRST %s ROWS ONLY
', query_vector, table_name, formated, query_vector, k);
END
$$;

alter function knn_in_exact(bytea, integer, character varying [])
  owner to postgres;

