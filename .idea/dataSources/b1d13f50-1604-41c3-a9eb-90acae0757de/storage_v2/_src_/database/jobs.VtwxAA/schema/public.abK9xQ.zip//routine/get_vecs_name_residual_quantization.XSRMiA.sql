create function get_vecs_name_residual_quantization()
  returns regclass
immutable
language sql
as $$
SELECT regclass 'fine_quantization'
$$;

alter function get_vecs_name_residual_quantization()
  owner to postgres;

