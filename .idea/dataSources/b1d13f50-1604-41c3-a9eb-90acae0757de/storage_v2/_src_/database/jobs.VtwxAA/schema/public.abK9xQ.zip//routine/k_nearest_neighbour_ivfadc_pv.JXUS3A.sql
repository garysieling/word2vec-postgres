create function k_nearest_neighbour_ivfadc_pv(input_vector anyarray, k integer)
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
fine_quantization_name varchar;
post_verif integer;
BEGIN
EXECUTE 'SELECT get_vecs_name_residual_quantization()' INTO fine_quantization_name;
EXECUTE 'SELECT get_pvf()' INTO post_verif;
RETURN QUERY EXECUTE format('
SELECT fq.word, cosine_similarity_bytea(v1.vector, v2.vector)
FROM ivfadc_search(''%s''::float4[], %s) AS (idx integer, distance float4)
INNER JOIN %s AS fq ON idx = fq.id
ORDER BY cosine_similarity_bytea(''%s''::float4[], fq.word) DESC
FETCH FIRST %s ROWS ONLY
', input_vector, post_verif*k, fine_quantization_name, input_vector, k);
END
$$;

alter function k_nearest_neighbour_ivfadc_pv(anyarray, integer)
  owner to postgres;

