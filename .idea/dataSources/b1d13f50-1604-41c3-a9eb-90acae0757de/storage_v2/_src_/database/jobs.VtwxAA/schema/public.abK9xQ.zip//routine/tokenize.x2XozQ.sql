create function tokenize(input text, OUT result bytea)
  returns bytea
language plpgsql
as $$
DECLARE
table_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE format('
SELECT vec_normalize_bytea(centroid_bytea(ARRAY(SELECT vector FROM %s WHERE word = ANY(regexp_split_to_array(''%s'', '' '')))))
', table_name, replace(input, '''', '''''')) INTO result;
END
$$;

alter function tokenize(text, out bytea)
  owner to postgres;

