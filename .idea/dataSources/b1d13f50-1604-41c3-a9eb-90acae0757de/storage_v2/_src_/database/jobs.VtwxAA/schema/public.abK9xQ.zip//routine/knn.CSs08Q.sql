create function knn(query character varying, k integer)
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
function_name varchar;
BEGIN
EXECUTE 'SELECT get_knn_function_name()' INTO function_name;
RETURN QUERY EXECUTE format('
SELECT * FROM %s(''%s'', %s)
', function_name,  replace(query, '''', ''''''), k);
END
$$;

alter function knn(varchar, integer)
  owner to postgres;

