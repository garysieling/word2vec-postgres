create function get_vecs_name_codebook()
  returns regclass
immutable
language sql
as $$
SELECT regclass 'pq_codebook'
$$;

alter function get_vecs_name_codebook()
  owner to postgres;

