create function cosine_similarity(token1 character varying, token2 character varying, OUT result real)
  returns real
language plpgsql
as $$
DECLARE
table_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;

EXECUTE format('
SELECT cosine_similarity_bytea(t1.vector, t2.vector)
FROM %s AS t1, %s AS t2
WHERE (t1.word = ''%s'') AND (t2.word = ''%s'')
', table_name, table_name, replace(token1, '''', ''''''), replace(token2, '''', '''''')) INTO result;
END
$$;

alter function cosine_similarity(varchar, varchar, out real)
  owner to postgres;

