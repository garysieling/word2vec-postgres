create function cosine_similarity_norm(vector real[], token2 character varying, OUT result double precision)
  returns double precision
language plpgsql
as $$
DECLARE
table_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;

EXECUTE format('
SELECT cosine_similarity_norm(''%s''::float4[], t2.vector)
FROM %s AS t2
WHERE t2.word = ''%s''
', vector, table_name, replace(token2, '''', '''''')) INTO result;
END
$$;

alter function cosine_similarity_norm(real [], varchar, out double precision)
  owner to postgres;

