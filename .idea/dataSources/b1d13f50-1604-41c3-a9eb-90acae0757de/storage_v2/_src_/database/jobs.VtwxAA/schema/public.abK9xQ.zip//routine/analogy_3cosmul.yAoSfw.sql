create function analogy_3cosmul(w1 character varying, w2 character varying, w3 character varying, OUT result character varying)
  returns character varying
language plpgsql
as $$
DECLARE
table_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE format('
SELECT v4.word FROM %s AS v4
INNER JOIN %s AS v1 ON v1.word = ''%s''
INNER JOIN %s AS v2 ON v2.word = ''%s''
INNER JOIN %s AS v3 ON v3.word = ''%s''
WHERE v4.word NOT IN (''%s'', ''%s'', ''%s'')
ORDER BY (((cosine_similarity_bytea(v4.vector, v3.vector) + 1)/2) * ((cosine_similarity_bytea(v4.vector, v2.vector) + 1.0)/2.0)) /  (((cosine_similarity_bytea(v4.vector, v1.vector) + 1.0)/2.0)+0.001) DESC
FETCH FIRST 1 ROWS ONLY
', table_name, table_name, replace(w1, '''', ''''''), table_name, replace(w2, '''', ''''''), table_name, replace(w3, '''', ''''''), replace(w1, '''', ''''''), replace(w2, '''', ''''''), replace(w3, '''', '''''')) INTO result;
END
$$;

alter function analogy_3cosmul(varchar, varchar, varchar, out varchar)
  owner to postgres;

