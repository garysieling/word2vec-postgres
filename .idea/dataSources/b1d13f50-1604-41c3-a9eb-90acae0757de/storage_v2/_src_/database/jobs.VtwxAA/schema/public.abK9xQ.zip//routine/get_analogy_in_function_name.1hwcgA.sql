create function get_analogy_in_function_name()
  returns character varying
immutable
language sql
as $$
SELECT varchar 'analogy_3cosadd_in'
$$;

alter function get_analogy_in_function_name()
  owner to postgres;

