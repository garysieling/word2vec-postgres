create function set_groups_function(name character varying)
  returns void
language plpgsql
as $$
BEGIN
EXECUTE format('CREATE OR REPLACE FUNCTION get_groups_function_name() RETURNS varchar AS ''SELECT varchar ''''%s'''''' LANGUAGE sql IMMUTABLE', name);
END
$$;

alter function set_groups_function(varchar)
  owner to postgres;

