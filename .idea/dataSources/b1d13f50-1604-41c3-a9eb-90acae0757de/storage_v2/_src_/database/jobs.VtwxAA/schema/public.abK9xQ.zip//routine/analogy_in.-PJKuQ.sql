create function analogy_in(w1 character varying, w2 character varying, w3 character varying, input_set character varying[], OUT result character varying)
  returns character varying
language plpgsql
as $$
DECLARE
function_name varchar;
formated varchar[];
BEGIN
FOR I IN array_lower(input_set, 1)..array_upper(input_set, 1) LOOP
  formated[I] = replace(input_set[I], '''', '''''');
END LOOP;
-- replace(token, '''', '''''')
EXECUTE 'SELECT get_analogy_in_function_name()' INTO function_name;
EXECUTE format('
SELECT * FROM %s(''%s'', ''%s'',''%s'', ''%s''::varchar(100)[])
', function_name, replace(w1, '''', ''''''), replace(w2, '''', ''''''), replace(w3, '''', ''''''), formated) INTO result;
END
$$;

alter function analogy_in(varchar, varchar, varchar, character varying [], out varchar)
  owner to postgres;

