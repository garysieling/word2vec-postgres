create function set_knn_function(name character varying)
  returns void
language plpgsql
as $$
BEGIN
EXECUTE format('CREATE OR REPLACE FUNCTION get_knn_function_name() RETURNS varchar AS ''SELECT varchar ''''%s'''''' LANGUAGE sql IMMUTABLE', name);
END
$$;

alter function set_knn_function(varchar)
  owner to postgres;

