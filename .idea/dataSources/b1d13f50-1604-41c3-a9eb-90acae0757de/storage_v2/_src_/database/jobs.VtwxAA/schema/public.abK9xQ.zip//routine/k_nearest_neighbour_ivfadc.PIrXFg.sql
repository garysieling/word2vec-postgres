create function k_nearest_neighbour_ivfadc(token character varying, k integer)
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
table_name varchar;
fine_quantization_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE 'SELECT get_vecs_name_residual_quantization()' INTO fine_quantization_name;
RETURN QUERY EXECUTE format('
SELECT fq.word, (1.0 - (distance / 2.0))::float4
FROM %s AS gv, ivfadc_search(gv.vector, %s) AS (idx integer, distance float4)
INNER JOIN %s AS fq ON idx = fq.id
WHERE gv.word = ''%s''
', table_name, k, fine_quantization_name, replace(token, '''', ''''''));
END
$$;

alter function k_nearest_neighbour_ivfadc(varchar, integer)
  owner to postgres;

