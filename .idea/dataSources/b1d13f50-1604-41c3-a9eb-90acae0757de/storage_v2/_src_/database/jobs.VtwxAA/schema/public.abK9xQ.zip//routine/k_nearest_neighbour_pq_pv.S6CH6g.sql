create function k_nearest_neighbour_pq_pv(token character varying, k integer)
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
table_name varchar;
pq_quantization_name varchar;
post_verif integer;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE 'SELECT get_vecs_name_pq_quantization()' INTO pq_quantization_name;
EXECUTE 'SELECT get_pvf()' INTO post_verif;
RETURN QUERY EXECUTE format('
SELECT pqs.word AS word,  cosine_similarity_bytea(wv.vector, pqs.word) AS similarity
FROM %s as wv, pq_search(wv.vector, %s) AS (idx integer, distance float4)
INNER JOIN %s AS pqs ON idx = pqs.id
WHERE wv.word = ''%s''
ORDER BY cosine_similarity_bytea(wv.vector, pqs.word) DESC
FETCH FIRST %s ROWS ONLY
', table_name, post_verif*k, pq_quantization_name, replace(token, '''', ''''''), k);
END
$$;

alter function k_nearest_neighbour_pq_pv(varchar, integer)
  owner to postgres;

