create function analogy_3cosadd_ivfadc(w1 character varying, w2 character varying, w3 character varying, OUT result character varying)
  returns character varying
language plpgsql
as $$
DECLARE
table_name varchar;
pq_quantization_name varchar;
fine_quantization_name varchar;
post_verif integer;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE 'SELECT get_vecs_name_pq_quantization()' INTO pq_quantization_name;
EXECUTE 'SELECT get_vecs_name_residual_quantization()' INTO fine_quantization_name;
EXECUTE 'SELECT get_pvf()' INTO post_verif;
EXECUTE format('
SELECT fq.word FROM
%s AS v1,
%s AS v2,
%s AS v3,
ivfadc_search(vec_normalize_bytea(vec_plus_bytea(vec_minus_bytea(v3.vector, v1.vector), v2.vector)), %s) AS (idx integer, distance float4)
INNER JOIN %s AS fq ON idx = fq.id
INNER JOIN %s AS v4 ON v4.word = fq.word
WHERE (v1.word = ''%s'')
AND (v2.word = ''%s'')
AND (v3.word = ''%s'')
AND (fq.word != v1.word)
AND (fq.word != v2.word)
AND (fq.word != v3.word)
ORDER BY cosine_similarity_bytea(vec_plus_bytea(vec_minus_bytea(v3.vector, v1.vector), v2.vector), v4.vector) DESC
FETCH FIRST 1 ROWS ONLY
', table_name, table_name, table_name, post_verif+3, fine_quantization_name, table_name, replace(w1, '''', ''''''), replace(w2, '''', ''''''), replace(w3, '''', '''''')) INTO result;
END
$$;

alter function analogy_3cosadd_ivfadc(varchar, varchar, varchar, out varchar)
  owner to postgres;

