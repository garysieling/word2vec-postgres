create function k_nearest_neighbour_ivfadc_batch(input_set character varying[], k integer)
  returns TABLE(query character varying, target character varying, similarity real)
language plpgsql
as $$
DECLARE
table_name varchar;
fine_quantization_name varchar;
formated varchar[];
BEGIN
FOR I IN array_lower(input_set, 1)..array_upper(input_set, 1) LOOP
  formated[I] = replace(input_set[I], '''', '''''');
END LOOP;
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE 'SELECT get_vecs_name_residual_quantization()' INTO fine_quantization_name;
RETURN QUERY EXECUTE format('
SELECT fq.word, fq2.word, (1.0 - (distance / 2.0))::float4
FROM ivfadc_batch_search(ARRAY(SELECT id FROM %s WHERE word = ANY (''%s'')), %s) AS (idx integer, idxx integer, distance float4)
INNER JOIN %s AS fq ON idx = fq.id
INNER JOIN %s AS fq2 ON idxx = fq2.id
', table_name, formated, k, fine_quantization_name, fine_quantization_name);
END
$$;

alter function k_nearest_neighbour_ivfadc_batch(character varying [], integer)
  owner to postgres;

