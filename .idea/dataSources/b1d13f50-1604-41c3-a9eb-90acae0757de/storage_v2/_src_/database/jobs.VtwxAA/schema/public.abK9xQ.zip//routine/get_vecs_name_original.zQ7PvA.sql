create function get_vecs_name_original()
  returns regclass
immutable
language sql
as $$
SELECT regclass 'google_vecs'
$$;

alter function get_vecs_name_original()
  owner to postgres;

