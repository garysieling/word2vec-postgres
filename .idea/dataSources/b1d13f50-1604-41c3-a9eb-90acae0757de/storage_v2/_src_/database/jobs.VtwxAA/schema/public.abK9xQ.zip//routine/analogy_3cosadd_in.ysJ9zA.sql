create function analogy_3cosadd_in(w1 character varying, w2 character varying, w3 character varying, input_set character varying[], OUT result character varying)
  returns character varying
language plpgsql
as $$
DECLARE
table_name varchar;
formated varchar[];
command varchar;
test varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
FOR I IN array_lower(input_set, 1)..array_upper(input_set, 1) LOOP
  formated[I] = replace(input_set[I], '''', '''''');
END LOOP;
EXECUTE format('
SELECT v4.word
FROM %s AS v4
INNER JOIN %s AS v1 ON v1.word = ''%s''
INNER JOIN %s AS v2 ON v2.word = ''%s''
INNER JOIN %s AS v3 ON v3.word = ''%s''
WHERE (v4.word NOT IN (''%s'', ''%s'', ''%s'')) AND (v4.word = ANY (''%s''::varchar(100)[]))
ORDER BY cosine_similarity_bytea(vec_plus_bytea(vec_minus_bytea(v3.vector, v1.vector), v2.vector), v4.vector) DESC
FETCH FIRST 1 ROWS ONLY
', table_name, table_name, replace(w1, '''', ''''''), table_name, replace(w2, '''', ''''''), table_name, replace(w3, '''', ''''''), replace(w1, '''', ''''''), replace(w2, '''', ''''''), replace(w3, '''', ''''''), formated) INTO result;
END
$$;

alter function analogy_3cosadd_in(varchar, varchar, varchar, character varying [], out varchar)
  owner to postgres;

