create function get_knn_batch_function_name()
  returns character varying
immutable
language sql
as $$
SELECT varchar 'k_nearest_neighbour_ivfadc_batch'
$$;

alter function get_knn_batch_function_name()
  owner to postgres;

