create function set_analogy_function(name character varying)
  returns void
language plpgsql
as $$
BEGIN
EXECUTE format('CREATE OR REPLACE FUNCTION get_analogy_function_name() RETURNS varchar AS ''SELECT varchar ''''%s'''''' LANGUAGE sql IMMUTABLE', name);
END
$$;

alter function set_analogy_function(varchar)
  owner to postgres;

