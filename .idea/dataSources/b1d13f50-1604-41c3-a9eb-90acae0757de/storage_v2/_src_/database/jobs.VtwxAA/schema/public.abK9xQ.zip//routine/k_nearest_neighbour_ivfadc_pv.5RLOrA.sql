create function k_nearest_neighbour_ivfadc_pv(token character varying, k integer)
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
table_name varchar;
post_verif integer;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
EXECUTE 'SELECT get_pvf()' INTO post_verif;
RETURN QUERY EXECUTE format('
SELECT v2.word, cosine_similarity_bytea(v1.vector, v2.vector)
FROM %s AS v1, ivfadc_search(v1.vector, %s) AS (idx integer, distance float4)
INNER JOIN %s AS v2 ON idx = v2.id
WHERE v1.word = ''%s''
ORDER BY cosine_similarity_bytea(v1.vector, v2.vector) DESC
FETCH FIRST %s ROWS ONLY
', table_name, post_verif*k, table_name, replace(token, '''', ''''''), k);
END
$$;

alter function k_nearest_neighbour_ivfadc_pv(varchar, integer)
  owner to postgres;

