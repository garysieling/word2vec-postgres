create function grouping_func(tokens character varying[], groups character varying[])
  returns TABLE(token character varying, grouptoken character varying)
language plpgsql
as $$
DECLARE
table_name varchar;
groups_formated varchar[];
tokens_formated varchar[];
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
FOR I IN array_lower(groups, 1)..array_upper(groups, 1) LOOP
  groups_formated[I] = replace(groups[I], '''', '''''''''');
END LOOP;
FOR I IN array_lower(tokens, 1)..array_upper(tokens, 1) LOOP
  tokens_formated[I] = replace(tokens[I], '''', '''''''''');
END LOOP;

RETURN QUERY EXECUTE format('
SELECT v1.word, gt.word
FROM %s AS v1,
knn_in(v1.word, 1, ''%s''::varchar(100)[]) AS gt
WHERE v1.word = ANY(''%s''::varchar(100)[])
', table_name, groups_formated, tokens_formated);
END
$$;

alter function grouping_func(character varying [], character varying [])
  owner to postgres;

