create function knn_in_exact(query_vector bytea, k integer, input_set integer[])
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
table_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
RETURN QUERY EXECUTE format('
SELECT v2.word, cosine_similarity_bytea(''%s'', v2.vector) FROM %s AS v2
WHERE v2.id = ANY (''%s''::integer[])
ORDER BY cosine_similarity_bytea(''%s'', v2.vector) DESC
FETCH FIRST %s ROWS ONLY
', query_vector, table_name, input_set, query_vector, k);
END
$$;

alter function knn_in_exact(bytea, integer, integer [])
  owner to postgres;

