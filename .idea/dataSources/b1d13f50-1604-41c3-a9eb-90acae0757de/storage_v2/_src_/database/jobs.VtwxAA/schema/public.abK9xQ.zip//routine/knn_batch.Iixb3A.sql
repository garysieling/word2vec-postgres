create function knn_batch(query_set character varying[], k integer)
  returns TABLE(query character varying, target character varying, squaredistance real)
language plpgsql
as $$
DECLARE
function_name varchar;
formated varchar[];
BEGIN
FOR I IN array_lower(query_set, 1)..array_upper(query_set, 1) LOOP
  formated[I] = replace(query_set[I], '''', '''''');
END LOOP;
EXECUTE 'SELECT get_knn_batch_function_name()' INTO function_name;
RETURN QUERY EXECUTE format('
SELECT * FROM %s(''%s'', %s)
', function_name, formated, k);
END
$$;

alter function knn_batch(character varying [], integer)
  owner to postgres;

