create function get_pvf()
  returns integer
immutable
language sql
as $$
SELECT 20
$$;

alter function get_pvf()
  owner to postgres;

