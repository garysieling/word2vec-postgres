create function set_w(w integer)
  returns void
language plpgsql
as $$
BEGIN
EXECUTE format('CREATE OR REPLACE FUNCTION get_w() RETURNS integer AS ''SELECT %s'' LANGUAGE sql IMMUTABLE', w);
END
$$;

alter function set_w(integer)
  owner to postgres;

