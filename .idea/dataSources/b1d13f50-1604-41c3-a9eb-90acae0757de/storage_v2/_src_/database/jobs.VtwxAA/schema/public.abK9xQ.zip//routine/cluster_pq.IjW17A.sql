create function cluster_pq(tokens character varying[], k integer)
  returns TABLE(words character varying[])
language plpgsql
as $$
DECLARE
table_name varchar;
formated varchar[];
BEGIN
EXECUTE 'SELECT get_vecs_name()' INTO table_name;
FOR I IN array_lower(tokens, 1)..array_upper(tokens, 1) LOOP
  formated[I] = replace(tokens[I], '''', '''''');
END LOOP;

RETURN QUERY EXECUTE format('
SELECT array_agg(word)
FROM %s, cluster_pq_to_id(ARRAY(SELECT id FROM %s WHERE word = ANY (''%s''::varchar(100)[])), %s) AS (centroid float4[], ids int[])
WHERE id = ANY ((ids)::integer[])
GROUP BY centroid;
', table_name, table_name, formated, k);
END
$$;

alter function cluster_pq(character varying [], integer)
  owner to postgres;

