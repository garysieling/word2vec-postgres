create function get_vecs_name()
  returns regclass
immutable
language sql
as $$
SELECT regclass 'google_vecs_norm'
$$;

alter function get_vecs_name()
  owner to postgres;

