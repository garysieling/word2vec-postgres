create function get_vecs_name_residual_codebook()
  returns regclass
immutable
language sql
as $$
SELECT regclass 'residual_codebook'
$$;

alter function get_vecs_name_residual_codebook()
  owner to postgres;

