create function k_nearest_neighbour_ivfadc(input_vector bytea, k integer)
  returns TABLE(word character varying, similarity real)
language plpgsql
as $$
DECLARE
fine_quantization_name varchar;
BEGIN
EXECUTE 'SELECT get_vecs_name_residual_quantization()' INTO fine_quantization_name;
RETURN QUERY EXECUTE format('
SELECT fq.word, (1.0 - (distance / 2.0))::float4
FROM ivfadc_search(''%s'', %s) AS (idx integer, distance float4)
INNER JOIN %s AS fq ON idx = fq.id
', input_vector, k, fine_quantization_name);
END
$$;

alter function k_nearest_neighbour_ivfadc(bytea, integer)
  owner to postgres;

